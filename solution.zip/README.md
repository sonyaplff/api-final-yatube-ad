<<<<<<< HEAD
# api_final
api final
=======
# API для Yatube

Социальная сеть для публикации постов с возможностью комментирования и подписки на авторов.

## Установка

1. Клонируйте репозиторий:
```bash
git clone https://github.com/sonyaplff/api-final-yatube-ad.git
cd api-final-yatube-ad
>>>>>>> 9df6e5f4a80c5cafc78c274367bfec18d23206cc
