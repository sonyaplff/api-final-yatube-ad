<<<<<<< HEAD
from django.contrib.auth import get_user_model
from django.db import models

User = get_user_model()

class Group(models.Model):
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField()

    def __str__(self):
        return self.title

class Post(models.Model):
    text = models.TextField()
    pub_date = models.DateTimeField('Дата публикации', auto_now_add=True)
    author = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='posts')
    image = models.ImageField(
        upload_to='posts/', null=True, blank=True)
    group = models.ForeignKey(
        Group, on_delete=models.SET_NULL,
        related_name='posts', blank=True, null=True)

    def __str__(self):
        return self.text

class Comment(models.Model):
    author = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='comments')
    post = models.ForeignKey(
        Post, on_delete=models.CASCADE, related_name='comments')
    text = models.TextField()
    created = models.DateTimeField(
        'Дата добавления', auto_now_add=True, db_index=True)

class Follow(models.Model):
    user = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='follower')
    following = models.ForeignKey(
        User, on_delete=models.CASCADE, related_name='following')

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'following'], name='unique_follow')
        ]
=======
"from django.db import models" 
"from django.contrib.auth import get_user_model" 
"" 
"User = get_user_model()" 
"" 
"class Group(models.Model):" 
"    title = models.CharField(max_length=200)" 
"    slug = models.SlugField(unique=True)" 
"    description = models.TextField()" 
"" 
"class Post(models.Model):" 
"    text = models.TextField()" 
"    pub_date = models.DateTimeField('��� �㡫���樨', auto_now_add=True)" 
"    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='posts')" 
"    group = models.ForeignKey(Group, on_delete=models.SET_NULL, blank=True, null=True, related_name='posts')" 
"    image = models.ImageField(upload_to='posts/', null=True, blank=True)" 
"" 
"class Comment(models.Model):" 
"    author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='comments')" 
"    post = models.ForeignKey(Post, on_delete=models.CASCADE, related_name='comments')" 
"    text = models.TextField()" 
"    created = models.DateTimeField('��� ����������', auto_now_add=True, db_index=True)" 
"" 
"class Follow(models.Model):" 
"    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='follower')" 
"    following = models.ForeignKey(User, on_delete=models.CASCADE, related_name='following')" 
"" 
"    class Meta:" 
"        constraints = [" 
"            models.UniqueConstraint(fields=['user', 'following'], name='unique_follow')" 
"        ]" 
>>>>>>> 9df6e5f4a80c5cafc78c274367bfec18d23206cc
